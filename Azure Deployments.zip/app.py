"""
Defect Prediction Dashboard (Production Ready – Azure Compatible)
Run locally: python app.py
Deploy: gunicorn app:server
"""

import os
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from dash import Dash, dcc, html, Input, Output, callback
import warnings

warnings.filterwarnings("ignore")

# =====================================================
# Helper: Base path (works locally + Azure App Service)
# =====================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def load_csv(filename):
    """Safely load CSV from project directory."""
    try:
        filepath = os.path.join(BASE_DIR, filename)
        df = pd.read_csv(filepath)
        print(f"Loaded {filename} ({df.shape[0]} rows)")
        return df
    except FileNotFoundError:
        print(f"Warning: {filename} not found.")
        return None

print("Loading prediction output files...")

df_2025 = load_csv("2025_predictions_detailed.csv")
df_product_comp = load_csv("product_defect_comparison_2025_2026.csv")
df_counts_2026 = load_csv("2026_defect_counts_by_product.csv")
df_effort_2026 = load_csv("2026_effort_by_product.csv")
df_risk_2026 = load_csv("2026_product_risk.csv")

# =====================================================
# Initialize Dash App
# =====================================================
app = Dash(__name__, suppress_callback_exceptions=True)
server = app.server   # 🔥 REQUIRED FOR AZURE

app.title = "Defect Prediction Dashboard"

# =====================================================
# Layout
# =====================================================
app.layout = html.Div([
    html.H1("Defect Prediction Insights", style={"textAlign": "center"}),

    html.Div([
        html.Label("Select Product:"),
        dcc.Dropdown(
            id="product-dropdown",
            options=[{"label": "All Products", "value": "ALL"}] +
                    ([{"label": p, "value": p}
                      for p in df_2025["Product"].unique()]
                     if df_2025 is not None else []),
            value="ALL",
            clearable=False
        )
    ], style={"width": "300px", "margin": "20px auto"}),

    dcc.Tabs(id="tabs", value="tab-overview", children=[
        dcc.Tab(label="Overview", value="tab-overview"),
        dcc.Tab(label="Defect Counts", value="tab-defects"),
        dcc.Tab(label="Risk Analysis", value="tab-risk"),
        dcc.Tab(label="2025 Accuracy", value="tab-accuracy"),
    ]),

    html.Div(id="tab-content")
])

# =====================================================
# Callback Router
# =====================================================
@callback(
    Output("tab-content", "children"),
    [Input("tabs", "value"),
     Input("product-dropdown", "value")]
)
def render_tab(tab, selected_product):
    if tab == "tab-overview":
        return overview_layout(selected_product)
    elif tab == "tab-defects":
        return defect_layout(selected_product)
    elif tab == "tab-risk":
        return risk_layout(selected_product)
    elif tab == "tab-accuracy":
        return accuracy_layout(selected_product)
    return html.Div("Unknown tab")

# =====================================================
# Layout Functions
# =====================================================
def overview_layout(selected_product):
    children = []

    if df_2025 is not None:
        total_defects = len(df_2025)
        total_products = df_2025["Product"].nunique()
        avg_risk = df_2025.get("RiskProbability", pd.Series([0])).mean()

        children.append(html.Div([
            html.Div([html.H4("Total Defects 2025"),
                      html.P(total_defects)]),
            html.Div([html.H4("Products"),
                      html.P(total_products)]),
            html.Div([html.H4("Avg Risk Probability"),
                      html.P(f"{avg_risk:.2f}")]),
        ], style={"display": "flex",
                  "justify-content": "space-around"}))

    if df_product_comp is not None:
        data = df_product_comp.copy()
        if selected_product != "ALL":
            data = data[data["Product"] == selected_product]
        else:
            data = data.head(10)

        if "ActualDefects2025" in data.columns and \
           "ExpectedDefects2026" in data.columns:

            df_melt = data.melt(
                id_vars="Product",
                value_vars=["ActualDefects2025",
                            "ExpectedDefects2026"],
                var_name="Type",
                value_name="DefectCount"
            )

            fig = px.bar(
                df_melt,
                x="Product",
                y="DefectCount",
                color="Type",
                barmode="group",
                title="Actual 2025 vs Expected 2026 Defects"
            )

            children.append(dcc.Graph(figure=fig))

    if not children:
        children.append(html.Div("No overview data available."))

    return html.Div(children)

def defect_layout(selected_product):
    if df_product_comp is None:
        return html.Div("Defect comparison data not available.")

    data = df_product_comp.copy()
    if selected_product != "ALL":
        data = data[data["Product"] == selected_product]

    if "ActualDefects2025" not in data.columns or \
       "ExpectedDefects2026" not in data.columns:
        return html.Div("Required columns missing.")

    df_melt = data.melt(
        id_vars="Product",
        value_vars=["ActualDefects2025",
                    "ExpectedDefects2026"],
        var_name="Type",
        value_name="DefectCount"
    )

    fig = px.bar(
        df_melt,
        x="Product",
        y="DefectCount",
        color="Type",
        barmode="group",
        title="Actual vs Expected Defects"
    )

    return html.Div([dcc.Graph(figure=fig)])

def risk_layout(selected_product):
    if df_risk_2026 is None:
        return html.Div("Risk data not available.")

    data = df_risk_2026.copy()
    if selected_product != "ALL":
        data = data[data["Product"] == selected_product]

    fig = px.bar(
        data,
        x="Product",
        y="RiskProbability",
        title="Risk Probability 2026",
        color="RiskProbability",
        color_continuous_scale="Reds"
    )

    return html.Div([dcc.Graph(figure=fig)])

def accuracy_layout(selected_product):
    children = []

    if df_product_comp is not None and \
       "ActualDefects2025" in df_product_comp.columns:

        data = df_product_comp.copy()
        if selected_product != "ALL":
            data = data[data["Product"] == selected_product]

        fig = px.bar(
            data,
            x="Product",
            y="ActualDefects2025",
            title="Actual Defects 2025"
        )

        children.append(dcc.Graph(figure=fig))

    children.append(html.Div(
        [html.H3("Model Accuracy: 92.86%")],
        style={"textAlign": "center",
               "background": "#e6f7ff",
               "padding": "10px"}
    ))

    return html.Div(children)

# =====================================================
# Run (Local Dev Only)
# =====================================================
if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", 8000))
    )